#ifndef __UTILS_HPP__
#define __UTILS_HPP__

#include <geometry_msgs/Vector3.h>

#include <cmath>

namespace lab2_utils {

double vecLength(const geometry_msgs::Vector3 &v);

}  // namespace lab2_utils

#endif /* __UTILS_HPP__ */

namespace lab2_utils {

double vecLength(const geometry_msgs::Vector3 &v) {
    return std::sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
}

}  // namespace lab2_utils
